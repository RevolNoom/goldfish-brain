import chess
import evaluator as ev
import numpy as np
import time

MAX = 9999
MIN = -9999

def alphaBeta(board, depth, alpha, beta, isMax):
    if board.is_checkmate():
        if isMax: # Next turn is trắng
            return -10000
        else:
            return 10000
        
    if board.is_stalemate(): # Some how king of white or black can not move
        return 0
    
    if board.is_insufficient_material(): # Game is over
        return 0
    
    if depth == 0:
        return ev.evaluatePoint(board)
            

    if isMax:
        bestScore = MIN
        for move in board.legal_moves:
            board.push(move)
            score = alphaBeta(board, depth - 1, alpha, beta, False)
            board.pop()

            if alpha < score:
                alpha = score

            if bestScore < score:
                bestScore = score
                
            if alpha >= beta:
                break
        return bestScore
            
    else:
        bestScore = MAX
        for move in board.legal_moves:
            board.push(move)
            score = alphaBeta(board, depth - 1, alpha, beta, True)
            board.pop()

            if beta >= score:
                beta = score

            if bestScore > score:
                bestScore = score

            if alpha >= beta:
                break
        return bestScore
    
def findBestMove_v2(board, depth, isMax):
    if board.is_checkmate():
        return chess.Move.null()
        
    start = time.time()
    try:
        move = chess.polyglot.MemoryMappedReader("human.bin").weighted_choice(board).move
        end = time.time()
        print("Time: {} s".format(end - start))
        return move
    except:
        bestMove = chess.Move.null()
        alpha = -10000
        beta = 10000
        if isMax:
            bestScore = MIN
            for move in board.legal_moves:
                board.push(move)
                score = alphaBeta(board, depth - 1, alpha, beta, False)
                board.pop()
                if score > bestScore:
                    bestScore = score
                    bestMove = move
                if score > alpha:
                    alpha = score
                if alpha >= beta:
                    break
            end = time.time()
            print("Time: {} s".format(end - start))
            return bestMove
        else:
            bestScore = MAX
            for move in board.legal_moves:
                board.push(move)
                score = alphaBeta(board, depth - 1, alpha, beta, True)
                board.pop()
                if score < bestScore:
                    bestScore = score
                    bestMove = move
                if beta >= score:
                    beta = score
                if alpha >= beta:
                    break
            end = time.time()
            print("Time: {} s".format(end - start))
            return bestMove


