import sys
import chess
import alpha_beta as ab
# python test_tool.py fenString findBestMethod depth isWhite

# Just for check
print("List of argument: {}".format(sys.argv))

# Variable
fenString = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR" # python file.py none ... if no fen
findBestMethod = "" # ab : alpha beta, mn: minimax, ng: negamax
depth = 3
isWhite = 1 # 1 true 0 false

# Mode: = 1 if legal move else = 2 if find best move
mode = 0
board = None

if len(sys.argv) == 1:
    mode = 1
    board = chess.Board()
elif len(sys.argv) == 2:
    mode = 1
    if sys.argv[1] != "none":
        fenString = sys.argv[1]
        
    board = chess.Board(fenString)
else:
    mode = 2
    if sys.argv[1] != "none":
        fenString = sys.argv[1]
    findBestMethod = sys.argv[2]
    board = chess.Board(fenString)
    try:
        depth = int(sys.argv[3])
    except:
        depth = 3

    try:
        isWhite = int(sys.argv[4])
    except:
        isWhite = 1

# Demo
if mode == 1:
    pass
elif mode == 2:
    if findBestMethod == "ab":
        print("Run alpha beta method")
        move = ab.findBestMove_v2(board, depth, isWhite).uci()
        print(move)
    elif findBestMethod == "mn":
        print("Run miniMax method")
    elif findBestMethod == "ng":
        print("Run negaMax method")
    else:
        print("Something wrong here")
    






